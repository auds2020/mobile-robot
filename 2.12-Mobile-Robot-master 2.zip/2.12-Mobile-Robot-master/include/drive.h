void driveSetup();
void driveVoltsLR(float leftVolts, float rightVolts);
void driveVolts(float frontLeftVolts, float backLeftVolts, float frontRightVolts, float backRightVolts);
void driveLR(float leftPower, float rightPower);
void drive(float frontLeft, float backLeft , float frontRight, float backRight);
#define DRIVE_VOLTAGE 12
